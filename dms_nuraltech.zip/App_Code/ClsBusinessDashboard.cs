﻿#region Copyright(c) 2017 Zed-Axis Technologies All rights are reserved
/*/
* ====================================================================================================
* <copyright company="Zed Axis Technologies">
* COPYRIGHT (c) 2017 Zed Axis Technologies (P) Ltd. 
* ALL RIGHTS ARE RESERVED. REPRODUCTION OR TRANSMISSION IN WHOLE OR IN PART, 
* ANY FORM OR BY ANY MEANS, ELECTRONIC, MECHANICAL OR OTHERWISE, 
* WITHOUT THE PRIOR PERMISSION OF THE COPYRIGHT OWNER.
* </copyright>
* ====================================================================================================
* Created By : 
* Created On: 
 * Description: This is a copy of business dashboard from DataAccess.
* ====================================================================================================
 * Change Log
 * DD-MMM-YYYY, Name, #CCXX, Description
 * 12-May-2021, kishan singh , #CC01, New properties and methods created for Business Dashboard.
 ====================================================================================================
*/

#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;

namespace DataAccess
{
    
   public class ClsBusinessDashboard : IDisposable
   {
       DataTable d1;
       SqlParameter[] SqlParam;
       DataSet ds;
       private Int32 intUserID;
       private Int16 intUserRoleID;
       public Int16 SelfOrTeam { get; set; }
       public Int32 UserID
       {
           get { return intUserID; }
           set { intUserID = value; }
       }
       private string _strConnectionString;
       public string strConnectionString
       {
           get { return _strConnectionString; }
           set { _strConnectionString = value; }
       }
       private string _authKey;
       public string authKey
       {
           get { return _authKey; }
           set { _authKey = value; }
       }
       public int TotalRecords
       {
           get;
           set;
       }
       private DataSet _dsresult;
       private DataTable _dtResult;
       public DataSet dsresult
       {
           get
           {
               return _dsresult;
           }
           set
           {
               _dsresult = value;
           }
       }
       public DataTable dtresult
       {
           get { return _dtResult; }
           set { _dtResult = value; }
       }
       private string _strError;
       public string Error
       {
           get
           {
               return _strError;
           }

           private set
           {
               _strError = value;
           }
       }
       private int _intResult;
       public int intResult
       {
           get { return _intResult; }
           set { _intResult = value; }
       }
       private Int32 _accountId = 0;
       public Int32 accountId
       {
           get { return _accountId; }
           set { _accountId = value; }
       }
       public DateTime? SaleFromDate { get; set; }
       public DateTime? SaleToDate { get; set; }
       private Int32 _EntityId = 0;
       public Int32 EntityId
       {
           get { return _EntityId; }
           set { _EntityId = value; }
       }
       private Int32 _EntityTypeId = 0;
       public Int32 EntityTypeId
       {
           get { return _EntityTypeId; }
           set { _EntityTypeId = value; }
       }
       private Int32 _BaseEntityTypeID = 0;
       public Int32 BaseEntityTypeID
       {
           get { return _BaseEntityTypeID; }
           set { _BaseEntityTypeID = value; }
       }
       private Int32 _RoleId = 0;
       public Int32 RoleId
       {
           get { return _RoleId; }
           set { _RoleId = value; }
       }
       private Int32 _TopType = 0;
       public Int32 TopType
       {
           get { return _TopType; }
           set { _TopType = value; }
       }

       
       public DataSet GetUserOrderListData()
       {
           try
           {
               SqlParameter[] objSqlParam = new SqlParameter[6];
               objSqlParam[0] = new SqlParameter("@Out_Param", SqlDbType.TinyInt, 2);
               objSqlParam[0].Direction = ParameterDirection.Output;
               objSqlParam[1] = new SqlParameter("@Out_Error", SqlDbType.VarChar, 3000);
               objSqlParam[1].Direction = ParameterDirection.Output;
               objSqlParam[2] = new SqlParameter("@UserId", UserID);
               objSqlParam[3] = new SqlParameter("@TotalRecords", SqlDbType.BigInt, 8);
               objSqlParam[3].Direction = ParameterDirection.Output;
               objSqlParam[4] = new SqlParameter("@AccountIdOut", SqlDbType.Int);
               objSqlParam[4].Direction = ParameterDirection.Output;
               objSqlParam[5] = new SqlParameter("@authKey", authKey);
               dsresult = DataAccess.Instance.GetDataSetFromDatabase("prcOrderDashboardDataAPI", CommandType.StoredProcedure, objSqlParam);
               intResult = Convert.ToInt16(objSqlParam[0].Value);
               accountId = 0; //Convert.ToInt32(objSqlParam[4].Value);
               if (objSqlParam[1].Value != null && Convert.ToString(objSqlParam[1].Value).Trim() != "")
               {
                   Error = Convert.ToString(objSqlParam[1].Value);
               }
               TotalRecords = Convert.ToInt32(objSqlParam[3].Value);
               return dsresult;
           }
           catch (Exception ex)
           {
               throw ex;
           }
       }

       public DataSet GetUserAttandanceDashboardList()
       {
           try
           {
               SqlParameter[] objSqlParam = new SqlParameter[7];
               objSqlParam[0] = new SqlParameter("@Out_Param", SqlDbType.TinyInt, 2);
               objSqlParam[0].Direction = ParameterDirection.Output;
               objSqlParam[1] = new SqlParameter("@Out_Error", SqlDbType.VarChar, 3000);
               objSqlParam[1].Direction = ParameterDirection.Output;
               objSqlParam[2] = new SqlParameter("@UserId", UserID);
               objSqlParam[3] = new SqlParameter("@TotalRecords", SqlDbType.BigInt, 8);
               objSqlParam[3].Direction = ParameterDirection.Output;
               objSqlParam[4] = new SqlParameter("@AccountIdOut", SqlDbType.Int);
               objSqlParam[4].Direction = ParameterDirection.Output;
               objSqlParam[5] = new SqlParameter("@authKey", authKey);
               objSqlParam[6] = new SqlParameter("@SelfOrTeam", SelfOrTeam);
               dsresult = DataAccess.Instance.GetDataSetFromDatabase("prcAttendanceDashboardDataAPI", CommandType.StoredProcedure, objSqlParam);
               intResult = Convert.ToInt16(objSqlParam[0].Value);
               accountId = Convert.ToInt32(objSqlParam[4].Value);
               if (objSqlParam[1].Value != null && Convert.ToString(objSqlParam[1].Value).Trim() != "")
               {
                   Error = Convert.ToString(objSqlParam[1].Value);
               }
               TotalRecords = Convert.ToInt32(objSqlParam[3].Value);
               return dsresult;
           }
           catch (Exception ex)
           {
               throw ex;
           }
       }

       public DataSet GetUserLeaveDashboardList()
       {
           try
           {
               SqlParameter[] objSqlParam = new SqlParameter[7];
               objSqlParam[0] = new SqlParameter("@Out_Param", SqlDbType.TinyInt, 2);
               objSqlParam[0].Direction = ParameterDirection.Output;
               objSqlParam[1] = new SqlParameter("@Out_Error", SqlDbType.VarChar, 3000);
               objSqlParam[1].Direction = ParameterDirection.Output;
               objSqlParam[2] = new SqlParameter("@UserId", UserID);
               objSqlParam[3] = new SqlParameter("@TotalRecords", SqlDbType.BigInt, 8);
               objSqlParam[3].Direction = ParameterDirection.Output;
               objSqlParam[4] = new SqlParameter("@AccountIdOut", SqlDbType.Int);
               objSqlParam[4].Direction = ParameterDirection.Output;
               objSqlParam[5] = new SqlParameter("@authKey", authKey);
               objSqlParam[6] = new SqlParameter("@SelfOrTeam", SelfOrTeam);
               dsresult = DataAccess.Instance.GetDataSetFromDatabase("prcLeaveDashboardDataAPI", CommandType.StoredProcedure, objSqlParam);
               intResult = Convert.ToInt16(objSqlParam[0].Value);
               accountId = Convert.ToInt32(objSqlParam[4].Value);
               if (objSqlParam[1].Value != null && Convert.ToString(objSqlParam[1].Value).Trim() != "")
               {
                   Error = Convert.ToString(objSqlParam[1].Value);
               }
               TotalRecords = Convert.ToInt32(objSqlParam[3].Value);
               return dsresult;
           }
           catch (Exception ex)
           {
               throw ex;
           }
       }

       public DataSet GetUserTravelDistanceListData()
       {
           try
           {
               SqlParameter[] objSqlParam = new SqlParameter[7];
               objSqlParam[0] = new SqlParameter("@Out_Param", SqlDbType.TinyInt, 2);
               objSqlParam[0].Direction = ParameterDirection.Output;
               objSqlParam[1] = new SqlParameter("@Out_Error", SqlDbType.VarChar, 3000);
               objSqlParam[1].Direction = ParameterDirection.Output;
               objSqlParam[2] = new SqlParameter("@UserId", UserID);
               objSqlParam[3] = new SqlParameter("@TotalRecords", SqlDbType.BigInt, 8);
               objSqlParam[3].Direction = ParameterDirection.Output;
               objSqlParam[4] = new SqlParameter("@AccountIdOut", SqlDbType.Int);
               objSqlParam[4].Direction = ParameterDirection.Output;
               objSqlParam[5] = new SqlParameter("@authKey", authKey);
               objSqlParam[6] = new SqlParameter("@SelfOrTeam", SelfOrTeam);
               dsresult = DataAccess.Instance.GetDataSetFromDatabase("prcTraveledDistanceDashboardDataAPI", CommandType.StoredProcedure, objSqlParam);
               intResult = Convert.ToInt16(objSqlParam[0].Value);
               accountId = Convert.ToInt32(objSqlParam[4].Value);
               if (objSqlParam[1].Value != null && Convert.ToString(objSqlParam[1].Value).Trim() != "")
               {
                   Error = Convert.ToString(objSqlParam[1].Value);
               }
               TotalRecords = Convert.ToInt32(objSqlParam[3].Value);
               return dsresult;
           }
           catch (Exception ex)
           {
               throw ex;
           }
       }

       public DataSet GetUserTimeSpendInMarketListData()
       {
           try
           {
               SqlParameter[] objSqlParam = new SqlParameter[7];
               objSqlParam[0] = new SqlParameter("@Out_Param", SqlDbType.TinyInt, 2);
               objSqlParam[0].Direction = ParameterDirection.Output;
               objSqlParam[1] = new SqlParameter("@Out_Error", SqlDbType.VarChar, 3000);
               objSqlParam[1].Direction = ParameterDirection.Output;
               objSqlParam[2] = new SqlParameter("@UserId", UserID);
               objSqlParam[3] = new SqlParameter("@TotalRecords", SqlDbType.BigInt, 8);
               objSqlParam[3].Direction = ParameterDirection.Output;
               objSqlParam[4] = new SqlParameter("@AccountIdOut", SqlDbType.Int);
               objSqlParam[4].Direction = ParameterDirection.Output;
               objSqlParam[5] = new SqlParameter("@authKey", authKey);
               objSqlParam[6] = new SqlParameter("@SelfOrTeam", SelfOrTeam);
               dsresult = DataAccess.Instance.GetDataSetFromDatabase("prcTimeSpendInMarketDashboardDataAPI", CommandType.StoredProcedure, objSqlParam);
               intResult = Convert.ToInt16(objSqlParam[0].Value);
               accountId = Convert.ToInt32(objSqlParam[4].Value);
               if (objSqlParam[1].Value != null && Convert.ToString(objSqlParam[1].Value).Trim() != "")
               {
                   Error = Convert.ToString(objSqlParam[1].Value);
               }
               TotalRecords = Convert.ToInt32(objSqlParam[3].Value);
               return dsresult;
           }
           catch (Exception ex)
           {
               throw ex;
           }
       }

       public DataSet GetUserPropectListData()
       {
           try
           {
               SqlParameter[] objSqlParam = new SqlParameter[7];
               objSqlParam[0] = new SqlParameter("@Out_Param", SqlDbType.TinyInt, 2);
               objSqlParam[0].Direction = ParameterDirection.Output;
               objSqlParam[1] = new SqlParameter("@Out_Error", SqlDbType.VarChar, 3000);
               objSqlParam[1].Direction = ParameterDirection.Output;
               objSqlParam[2] = new SqlParameter("@UserId", UserID);
               objSqlParam[3] = new SqlParameter("@TotalRecords", SqlDbType.BigInt, 8);
               objSqlParam[3].Direction = ParameterDirection.Output;
               objSqlParam[4] = new SqlParameter("@AccountIdOut", SqlDbType.Int);
               objSqlParam[4].Direction = ParameterDirection.Output;
               objSqlParam[5] = new SqlParameter("@authKey", authKey);
               objSqlParam[6] = new SqlParameter("@SelfOrTeam", SelfOrTeam);
               dsresult = DataAccess.Instance.GetDataSetFromDatabase("prcProsectDashboardDataAPI", CommandType.StoredProcedure, objSqlParam);
               intResult = Convert.ToInt16(objSqlParam[0].Value);
               accountId = Convert.ToInt32(objSqlParam[4].Value);
               if (objSqlParam[1].Value != null && Convert.ToString(objSqlParam[1].Value).Trim() != "")
               {
                   Error = Convert.ToString(objSqlParam[1].Value);
               }
               TotalRecords = Convert.ToInt32(objSqlParam[3].Value);
               return dsresult;
           }
           catch (Exception ex)
           {
               throw ex;
           }
       }

       public DataSet GetUserExpenseListData()
       {
           try
           {
               SqlParameter[] objSqlParam = new SqlParameter[7];
               objSqlParam[0] = new SqlParameter("@Out_Param", SqlDbType.TinyInt, 2);
               objSqlParam[0].Direction = ParameterDirection.Output;
               objSqlParam[1] = new SqlParameter("@Out_Error", SqlDbType.VarChar, 3000);
               objSqlParam[1].Direction = ParameterDirection.Output;
               objSqlParam[2] = new SqlParameter("@UserId", UserID);
               objSqlParam[3] = new SqlParameter("@TotalRecords", SqlDbType.BigInt, 8);
               objSqlParam[3].Direction = ParameterDirection.Output;
               objSqlParam[4] = new SqlParameter("@AccountIdOut", SqlDbType.Int);
               objSqlParam[4].Direction = ParameterDirection.Output;
               objSqlParam[5] = new SqlParameter("@authKey", authKey);
               objSqlParam[6] = new SqlParameter("@SelfOrTeam", SelfOrTeam);
               dsresult = DataAccess.Instance.GetDataSetFromDatabase("prcExpenseDashboardDataAPI", CommandType.StoredProcedure, objSqlParam);
               intResult = Convert.ToInt16(objSqlParam[0].Value);
               accountId = Convert.ToInt32(objSqlParam[4].Value);
               if (objSqlParam[1].Value != null && Convert.ToString(objSqlParam[1].Value).Trim() != "")
               {
                   Error = Convert.ToString(objSqlParam[1].Value);
               }
               TotalRecords = Convert.ToInt32(objSqlParam[3].Value);
               return dsresult;
           }
           catch (Exception ex)
           {
               throw ex;
           }
       }

       public DataSet GetUserAverageTimeListData()
       {
           try
           {
               SqlParameter[] objSqlParam = new SqlParameter[7];
               objSqlParam[0] = new SqlParameter("@Out_Param", SqlDbType.TinyInt, 2);
               objSqlParam[0].Direction = ParameterDirection.Output;
               objSqlParam[1] = new SqlParameter("@Out_Error", SqlDbType.VarChar, 3000);
               objSqlParam[1].Direction = ParameterDirection.Output;
               objSqlParam[2] = new SqlParameter("@UserId", UserID);
               objSqlParam[3] = new SqlParameter("@TotalRecords", SqlDbType.BigInt, 8);
               objSqlParam[3].Direction = ParameterDirection.Output;
               objSqlParam[4] = new SqlParameter("@AccountIdOut", SqlDbType.Int);
               objSqlParam[4].Direction = ParameterDirection.Output;
               objSqlParam[5] = new SqlParameter("@authKey", authKey);
               objSqlParam[6] = new SqlParameter("@SelfOrTeam", SelfOrTeam);
               dsresult = DataAccess.Instance.GetDataSetFromDatabase("prcAverageTimeDashboardDataAPI", CommandType.StoredProcedure, objSqlParam);
               intResult = Convert.ToInt16(objSqlParam[0].Value);
               accountId = Convert.ToInt32(objSqlParam[4].Value);
               if (objSqlParam[1].Value != null && Convert.ToString(objSqlParam[1].Value).Trim() != "")
               {
                   Error = Convert.ToString(objSqlParam[1].Value);
               }
               TotalRecords = Convert.ToInt32(objSqlParam[3].Value);
               return dsresult;
           }
           catch (Exception ex)
           {
               throw ex;
           }
       }

       public DataSet GetTodayTeamAttandanceListData()
       {
           try
           {
               SqlParameter[] objSqlParam = new SqlParameter[7];
               objSqlParam[0] = new SqlParameter("@Out_Param", SqlDbType.TinyInt, 2);
               objSqlParam[0].Direction = ParameterDirection.Output;
               objSqlParam[1] = new SqlParameter("@Out_Error", SqlDbType.VarChar, 3000);
               objSqlParam[1].Direction = ParameterDirection.Output;
               objSqlParam[2] = new SqlParameter("@UserId", UserID);
               objSqlParam[3] = new SqlParameter("@TotalRecords", SqlDbType.BigInt, 8);
               objSqlParam[3].Direction = ParameterDirection.Output;
               objSqlParam[4] = new SqlParameter("@AccountIdOut", SqlDbType.Int);
               objSqlParam[4].Direction = ParameterDirection.Output;
               objSqlParam[5] = new SqlParameter("@authKey", authKey);
               objSqlParam[6] = new SqlParameter("@SelfOrTeam", SelfOrTeam);
               dsresult = DataAccess.Instance.GetDataSetFromDatabase("prcTodayTeamAttandanceDashboardDataAPI", CommandType.StoredProcedure, objSqlParam);
               intResult = Convert.ToInt16(objSqlParam[0].Value);
               accountId = Convert.ToInt32(objSqlParam[4].Value);
               if (objSqlParam[1].Value != null && Convert.ToString(objSqlParam[1].Value).Trim() != "")
               {
                   Error = Convert.ToString(objSqlParam[1].Value);
               }
               TotalRecords = Convert.ToInt32(objSqlParam[3].Value);
               return dsresult;
           }
           catch (Exception ex)
           {
               throw ex;
           }
       }

       public DataSet GetUserSaleListData()
       {
           try
           {
               SqlParameter[] objSqlParam = new SqlParameter[7];
               objSqlParam[0] = new SqlParameter("@Out_Param", SqlDbType.TinyInt, 2);
               objSqlParam[0].Direction = ParameterDirection.Output;
               objSqlParam[1] = new SqlParameter("@Out_Error", SqlDbType.VarChar, 3000);
               objSqlParam[1].Direction = ParameterDirection.Output;
               objSqlParam[2] = new SqlParameter("@UserId", UserID);
               objSqlParam[3] = new SqlParameter("@TotalRecords", SqlDbType.BigInt, 8);
               objSqlParam[3].Direction = ParameterDirection.Output;
               objSqlParam[4] = new SqlParameter("@AccountIdOut", SqlDbType.Int);
               objSqlParam[4].Direction = ParameterDirection.Output;
               objSqlParam[5] = new SqlParameter("@authKey", authKey);
               objSqlParam[6] = new SqlParameter("@SelfOrTeam", SelfOrTeam);
               dsresult = DataAccess.Instance.GetDataSetFromDatabase("prcUserSalesDashboardDataAPI", CommandType.StoredProcedure, objSqlParam);
               intResult = Convert.ToInt16(objSqlParam[0].Value);
               accountId = Convert.ToInt32(objSqlParam[4].Value);
               if (objSqlParam[1].Value != null && Convert.ToString(objSqlParam[1].Value).Trim() != "")
               {
                   Error = Convert.ToString(objSqlParam[1].Value);
               }
               TotalRecords = Convert.ToInt32(objSqlParam[3].Value);
               return dsresult;
           }
           catch (Exception ex)
           {
               throw ex;
           }
       }

       public DataSet GetUserTopSalesMenListData()
       {
           try
           {
               SqlParameter[] objSqlParam = new SqlParameter[6];
               objSqlParam[0] = new SqlParameter("@Out_Param", SqlDbType.TinyInt, 2);
               objSqlParam[0].Direction = ParameterDirection.Output;
               objSqlParam[1] = new SqlParameter("@Out_Error", SqlDbType.VarChar, 3000);
               objSqlParam[1].Direction = ParameterDirection.Output;
               objSqlParam[2] = new SqlParameter("@UserId", UserID);
               objSqlParam[3] = new SqlParameter("@TotalRecords", SqlDbType.BigInt, 8);
               objSqlParam[3].Direction = ParameterDirection.Output;
               objSqlParam[4] = new SqlParameter("@Out_ParamEntityId", SqlDbType.Int);
               objSqlParam[4].Direction = ParameterDirection.Output;
               objSqlParam[5] = new SqlParameter("@authKey", authKey);
               dsresult = DataAccess.Instance.GetDataSetFromDatabase("prcGetTopSalesMenAPI", CommandType.StoredProcedure, objSqlParam);
               intResult = Convert.ToInt16(objSqlParam[0].Value);
               string value = objSqlParam[4].Value.ToString();
               if (value != null && value!="")
               {
                   accountId = Convert.ToInt32(objSqlParam[4].Value);
               }
               
               if (objSqlParam[1].Value != null && Convert.ToString(objSqlParam[1].Value).Trim() != "")
               {
                   Error = Convert.ToString(objSqlParam[1].Value);
               }
               TotalRecords = Convert.ToInt32(objSqlParam[3].Value);
               return dsresult;
           }
           catch (Exception ex)
           {
               throw ex;
           }
       }

       public DataSet GetUserBeatPlanListData()
       {
           try
           {
               SqlParameter[] objSqlParam = new SqlParameter[9];
               objSqlParam[0] = new SqlParameter("@Out_Param", SqlDbType.TinyInt, 2);
               objSqlParam[0].Direction = ParameterDirection.Output;
               objSqlParam[1] = new SqlParameter("@Out_Error", SqlDbType.VarChar, 3000);
               objSqlParam[1].Direction = ParameterDirection.Output;
               objSqlParam[2] = new SqlParameter("@UserId", UserID);
               objSqlParam[3] = new SqlParameter("@TotalRecords", SqlDbType.BigInt, 8);
               objSqlParam[3].Direction = ParameterDirection.Output;
               objSqlParam[4] = new SqlParameter("@AccountIdOut", SqlDbType.Int);
               objSqlParam[4].Direction = ParameterDirection.Output;
               objSqlParam[5] = new SqlParameter("@authKey", authKey);
               objSqlParam[6] = new SqlParameter("@EntityId", EntityId);
               objSqlParam[7] = new SqlParameter("@EntityTypeId", EntityTypeId);
               objSqlParam[8] = new SqlParameter("@BaseEntityTypeID", BaseEntityTypeID);
               dsresult = DataAccess.Instance.GetDataSetFromDatabase("prcGetBeatPlanSummaryAPI", CommandType.StoredProcedure, objSqlParam);
               intResult = Convert.ToInt16(objSqlParam[0].Value);
               accountId = Convert.ToInt32(objSqlParam[4].Value);
               if (objSqlParam[1].Value != null && Convert.ToString(objSqlParam[1].Value).Trim() != "")
               {
                   Error = Convert.ToString(objSqlParam[1].Value);
               }
               TotalRecords = Convert.ToInt32(objSqlParam[3].Value);
               return dsresult;
           }
           catch (Exception ex)
           {
               throw ex;
           }
       }

       public DataSet GetTopModelListData()
       {
           try
           {
               SqlParameter[] objSqlParam = new SqlParameter[7];
               objSqlParam[0] = new SqlParameter("@OutParam", SqlDbType.TinyInt, 2);
               objSqlParam[0].Direction = ParameterDirection.Output;
               objSqlParam[1] = new SqlParameter("@OutError", SqlDbType.VarChar, 3000);
               objSqlParam[1].Direction = ParameterDirection.Output;
               objSqlParam[2] = new SqlParameter("@UserId", UserID);
               objSqlParam[3] = new SqlParameter("@OutUserId", SqlDbType.BigInt, 8);
               objSqlParam[3].Direction = ParameterDirection.Output;
               objSqlParam[4] = new SqlParameter("@OutaccountId", SqlDbType.Int);
               objSqlParam[4].Direction = ParameterDirection.Output;
               objSqlParam[5] = new SqlParameter("@authKey", authKey);
               objSqlParam[6] = new SqlParameter("@RoleID", RoleId);
               dsresult = DataAccess.Instance.GetDataSetFromDatabase("prcGetTopModels", CommandType.StoredProcedure, objSqlParam);
               intResult = Convert.ToInt16(objSqlParam[0].Value);
               accountId = Convert.ToInt32(objSqlParam[4].Value);
               if (objSqlParam[1].Value != null && Convert.ToString(objSqlParam[1].Value).Trim() != "")
               {
                   Error = Convert.ToString(objSqlParam[1].Value);
               }

               if (objSqlParam[3].Value.ToString() != "" && objSqlParam[3].Value.ToString()!=null)
               {
                   TotalRecords = Convert.ToInt32(objSqlParam[3].Value);
               }
               
               return dsresult;
           }
           catch (Exception ex)
           {
               throw ex;
           }
       }

       public DataSet GetTargetVsAchievementListData()
       {
           try
           {
               SqlParameter[] objSqlParam = new SqlParameter[7];
               objSqlParam[0] = new SqlParameter("@Out_Param", SqlDbType.TinyInt, 2);
               objSqlParam[0].Direction = ParameterDirection.Output;
               objSqlParam[1] = new SqlParameter("@Out_Error", SqlDbType.VarChar, 3000);
               objSqlParam[1].Direction = ParameterDirection.Output;
               objSqlParam[2] = new SqlParameter("@UserId", UserID);
               objSqlParam[3] = new SqlParameter("@TotalRecords", SqlDbType.BigInt, 8);
               objSqlParam[3].Direction = ParameterDirection.Output;
               objSqlParam[4] = new SqlParameter("@OutaccountId", SqlDbType.Int);
               objSqlParam[4].Direction = ParameterDirection.Output;
               objSqlParam[5] = new SqlParameter("@OutUserId", SqlDbType.Int);
               objSqlParam[5].Direction = ParameterDirection.Output;
               objSqlParam[6] = new SqlParameter("@authKey", authKey);
               dsresult = DataAccess.Instance.GetDataSetFromDatabase("prcGetTargetVsAchievementDashboardAPI", CommandType.StoredProcedure, objSqlParam);
               intResult = Convert.ToInt16(objSqlParam[0].Value);
               accountId = Convert.ToInt32(objSqlParam[4].Value);
               if (objSqlParam[1].Value != null && Convert.ToString(objSqlParam[1].Value).Trim() != "")
               {
                   Error = Convert.ToString(objSqlParam[1].Value);
               }
               TotalRecords = Convert.ToInt32(objSqlParam[3].Value);
               return dsresult;
           }
           catch (Exception ex)
           {
               throw ex;
           }
       }

       public DataSet GetRankingListData()
       {
           try
           {
               SqlParameter[] objSqlParam = new SqlParameter[6];
               objSqlParam[0] = new SqlParameter("@Out_Param", SqlDbType.TinyInt, 2);
               objSqlParam[0].Direction = ParameterDirection.Output;
               objSqlParam[1] = new SqlParameter("@Out_Error", SqlDbType.VarChar, 3000);
               objSqlParam[1].Direction = ParameterDirection.Output;
               objSqlParam[2] = new SqlParameter("@UserId", UserID);
               objSqlParam[3] = new SqlParameter("@TotalRecords", SqlDbType.BigInt, 8);
               objSqlParam[3].Direction = ParameterDirection.Output;
               objSqlParam[4] = new SqlParameter("@AccountIdOut", SqlDbType.Int);
               objSqlParam[4].Direction = ParameterDirection.Output;
               objSqlParam[5] = new SqlParameter("@authKey", authKey);
               dsresult = DataAccess.Instance.GetDataSetFromDatabase("prcGetRakingDataAPI", CommandType.StoredProcedure, objSqlParam);
               intResult = Convert.ToInt16(objSqlParam[0].Value);
               accountId = Convert.ToInt32(objSqlParam[4].Value);
               if (objSqlParam[1].Value != null && Convert.ToString(objSqlParam[1].Value).Trim() != "")
               {
                   Error = Convert.ToString(objSqlParam[1].Value);
               }
               TotalRecords = Convert.ToInt32(objSqlParam[3].Value);
               return dsresult;
           }
           catch (Exception ex)
           {
               throw ex;
           }
       }

       public DataSet GetTopDistributorListData()
       {
           try
           {
               SqlParameter[] objSqlParam = new SqlParameter[8];
               objSqlParam[0] = new SqlParameter("@OutParam", SqlDbType.TinyInt, 2);
               objSqlParam[0].Direction = ParameterDirection.Output;
               objSqlParam[1] = new SqlParameter("@OutError", SqlDbType.VarChar, 3000);
               objSqlParam[1].Direction = ParameterDirection.Output;
               objSqlParam[2] = new SqlParameter("@UserId", UserID);
               objSqlParam[3] = new SqlParameter("@OutUserId", SqlDbType.Int);
               objSqlParam[3].Direction = ParameterDirection.Output;
               objSqlParam[4] = new SqlParameter("@OutaccountId", SqlDbType.Int);
               objSqlParam[4].Direction = ParameterDirection.Output;
               objSqlParam[5] = new SqlParameter("@authKey", authKey);
               objSqlParam[6] = new SqlParameter("@RoleID", RoleId);
               objSqlParam[7] = new SqlParameter("@TopType", TopType);
               dsresult = DataAccess.Instance.GetDataSetFromDatabase("prcGetTopDistributor", CommandType.StoredProcedure, objSqlParam);
               intResult = Convert.ToInt16(objSqlParam[0].Value);
               accountId = Convert.ToInt32(objSqlParam[4].Value);
               if (objSqlParam[1].Value != null && Convert.ToString(objSqlParam[1].Value).Trim() != "")
               {
                   Error = Convert.ToString(objSqlParam[1].Value);
               }
               if (objSqlParam[3].Value.ToString() != "" && objSqlParam[3].Value.ToString()!=null)
               {
                   TotalRecords = Convert.ToInt32(objSqlParam[3].Value);
               }
               return dsresult;
           }
           catch (Exception ex)
           {
               throw ex;
           }
       }

       public DataSet GetPaymentCollectionListData()
       {
           try
           {
               SqlParameter[] objSqlParam = new SqlParameter[9];
               objSqlParam[0] = new SqlParameter("@Out_Param", SqlDbType.TinyInt, 2);
               objSqlParam[0].Direction = ParameterDirection.Output;
               objSqlParam[1] = new SqlParameter("@Out_Error", SqlDbType.VarChar, 3000);
               objSqlParam[1].Direction = ParameterDirection.Output;
               objSqlParam[2] = new SqlParameter("@UserId", UserID);
               objSqlParam[3] = new SqlParameter("@TotalRecords", SqlDbType.BigInt, 8);
               objSqlParam[3].Direction = ParameterDirection.Output;
               objSqlParam[4] = new SqlParameter("@AccountIdOut", SqlDbType.Int);
               objSqlParam[4].Direction = ParameterDirection.Output;
               objSqlParam[5] = new SqlParameter("@authKey", authKey);
               objSqlParam[6] = new SqlParameter("@EntityId", EntityId);
               objSqlParam[7] = new SqlParameter("@EntityTypeId", EntityTypeId);
               objSqlParam[8] = new SqlParameter("@BaseEntityTypeID", BaseEntityTypeID);
               dsresult = DataAccess.Instance.GetDataSetFromDatabase("prcGetPaymentCollectionDashboardDetailAPI", CommandType.StoredProcedure, objSqlParam);
               intResult = Convert.ToInt16(objSqlParam[0].Value);
               accountId = Convert.ToInt32(objSqlParam[4].Value);
               if (objSqlParam[1].Value != null && Convert.ToString(objSqlParam[1].Value).Trim() != "")
               {
                   Error = Convert.ToString(objSqlParam[1].Value);
               }
               TotalRecords = Convert.ToInt32(objSqlParam[3].Value);
               return dsresult;
           }
           catch (Exception ex)
           {
               throw ex;
           }
       }

       public DataSet GetDashBoardWidget()
       {
           try
           {
               SqlParameter[] objSqlParam = new SqlParameter[7];
               objSqlParam[0] = new SqlParameter("@Out_Param", SqlDbType.TinyInt, 2);
               objSqlParam[0].Direction = ParameterDirection.Output;
               objSqlParam[1] = new SqlParameter("@Out_Error", SqlDbType.VarChar, 3000);
               objSqlParam[1].Direction = ParameterDirection.Output;
               objSqlParam[2] = new SqlParameter("@UserID", UserID);
               objSqlParam[3] = new SqlParameter("@TotalRecords", SqlDbType.BigInt, 8);
               objSqlParam[3].Direction = ParameterDirection.Output;
               objSqlParam[4] = new SqlParameter("@AccountIdOut", SqlDbType.Int);
               objSqlParam[4].Direction = ParameterDirection.Output;
               objSqlParam[5] = new SqlParameter("@AuthKey", authKey);
               objSqlParam[6] = new SqlParameter("@ParentUserId", 0);
               dsresult = DataAccess.Instance.GetDataSetFromDatabase("prcAPIGetDashboardWidgetList", CommandType.StoredProcedure, objSqlParam);
               intResult = Convert.ToInt16(objSqlParam[0].Value);
               if (objSqlParam[4].Value != null && Convert.ToString(objSqlParam[4].Value).Trim() != "")
               {
                   accountId = Convert.ToInt32(objSqlParam[4].Value);
               }
               if (objSqlParam[1].Value != null && Convert.ToString(objSqlParam[1].Value).Trim() != "")
               {
                   Error = Convert.ToString(objSqlParam[1].Value);
               }
               TotalRecords = Convert.ToInt32(objSqlParam[3].Value);
               return dsresult;
           }
           catch (Exception ex)
           {
               throw ex;
           }
       }

       

        # region dispose
        //Call Dispose to free resources explicitly
        private bool IsDisposed = false;
        public void Dispose()
        {
            //Pass true in dispose method to clean managed resources too and say GC to skip finalize 
            // in next line.
            Dispose(true);
            //If dispose is called already then say GC to skip finalize on this instance.
            GC.SuppressFinalize(this);
        }

        ~ClsBusinessDashboard()
        {
            //Pass false as param because no need to free managed resources when you call finalize it
            //  will be done
            //by GC itself as its work of finalize to manage managed resources.
            Dispose(false);
        }

        //Implement dispose to free resources
        protected virtual void Dispose(bool disposedStatus)
        {
            if (!IsDisposed)
            {
                IsDisposed = true;
                // Released unmanaged Resources
                if (disposedStatus)
                {
                    // Released managed Resources
                }
            }
        }

        #endregion

    }
}
