﻿#region Copyright(c) 2016 Zed-Axis Technologies All rights are reserved
/*/
 * ================================================================================================
 * ================================================================================================
 * COPYRIGHT (c) 2016 Zed Axis Technologies (P) Ltd.
 * ALL RIGHTS ARE RESERVED. REPRODUCTION OR TRANSMISSION IN WHOLE OR IN PART,
 * ANY FORM OR BY ANY MEANS, ELECTRONIC, MECHANICAL OR OTHERWISE, WITHOUT THE PRIOR PERMISSION OF THE COPYRIGHT OWNER.
 * ================================================================================================
 * Created By : Sumit Maurya
 * Created On : 01-Sep-2016
 * Description : This is a copy of MasterData.cs
 * ================================================================================================
 * Change Log:
 * ------------- 
 * DD-MMM-YYYY, Name, #CCXX, Description
 * 29-May-2017, Vijay Kumar Prajapati,#CC01,Add Method For Getlist For Region.
 * ====================================================================================================
 */
#endregion
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Data.SqlClient;
using System.Xml;
/*
 * 18 Mar 2015, Karam Chand Sharma, #CC01 , Create some new function to save , update and select tehsil data from master table
 * 23-May-2016, Sumit Maurya, #CC02, New Parameter supplied in method SelectStateInfo() to get state details according to parameter value.
 * 24-May-2016, Karam Chand Sharma, #CC03, As per client requriment tehsil will come under city now 
 * 22-May-2018,Vijay Kumar Prajapati,#CC04,Add method for zonemaster.
 * 20-July-2018,Vijay Kumar Prajapati,#CC05,Add method for BindRegion.
 */
namespace DataAccess
{
    public class MastersData : IDisposable
    {
        DataTable d1;
        string countryname; int countryid; short countrystatus; short countryselectionmode; short zonestatus/*#CC04 Added*/;

        int regionid; int activeid; string regionname; int stateregionid; /*Added #CC01*/

        SqlParameter[] SqlParam;
        public string error;
        Int32 IntResultCount = 0;

        # region country
        public Int32 Condition
        {
            get;
            set;
        }
        public Int32 UniqueID
        {
            get;
            set;
        }
        public Int16 Purpose
        {
            get;
            set;
        }

        public Int32 SalesChannelID
        {
            get;
            set;
        }
        public int CountryId
        {
            get { return countryid; }
            set { countryid = value; }
        }


        public string CountryName
        {
            get { return countryname; }
            set { countryname = value; }
        }

        public short CountryStatus
        {
            get { return countrystatus; }
            set { countrystatus = value; }

        }
        /*#CC04 Added*/
        public short ZoneStatus
        {
            get { return zonestatus; }
            set { zonestatus = value; }

        }
        /*#CC04 Added End*/
        public short CountrySelectionMode
        {
            get { return countryselectionmode; }
            set { countryselectionmode = value; }
        }
        /*Added #CC01*/
        public int RegionId
        {
            get { return regionid; }
            set { regionid = value; }
        }
        public string RegionName
        {
            get { return regionname; }
            set { regionname = value; }
        }
        public int State_Id
        {
            get { return stateid; }
            set { stateid = value; }
        }
        public string State_Name
        {
            get { return statename; }
            set { statename = value; }
        }
        public int StateRegionid
        {
            get { return stateregionid; }
            set { stateregionid = value; }
        }
         /*End #CC01*/
        /*#CC04 Added Started*/
        public int ZoneID { get; set; }
        public Int16 Active { get; set; }
        public int CountryID { get; set; }
        /*#CC04 Added End*/
        public DataTable SelectCountryInfo()
        {
            try
            {

                SqlParam = new SqlParameter[4];
                SqlParam[0] = new SqlParameter("@countryid", countryid);
                SqlParam[1] = new SqlParameter("@countryname", countryname);
                SqlParam[2] = new SqlParameter("@selectionmode", countryselectionmode);
                SqlParam[3] = new SqlParameter("@CompanyId", CompanyId);/*#CC06 Added*/
                d1 = DataAccess.Instance.GetTableFromDatabase("prcGetCountryDetails", CommandType.StoredProcedure, SqlParam);
                return d1;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataSet SelectSalesChannelAreainformation()
        {
            try
            {
                DataSet ds = new DataSet();
                SqlParam = new SqlParameter[4];
                SqlParam[0] = new SqlParameter("@countryid", countryid);
                SqlParam[1] = new SqlParameter("@countryname", countryname);
                SqlParam[2] = new SqlParameter("@selectionmode", countryselectionmode);
                SqlParam[3] = new SqlParameter("@SalesChannelId", SalesChannelID);
                ds = DataAccess.Instance.GetDataSetFromDatabase("prcGetSalesChannelAreainformation", CommandType.StoredProcedure, SqlParam);
                return ds;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public void InsertCountryInfo()
        {
            try
            {


                stateid = 0;

                SqlParam = new SqlParameter[4];
                SqlParam[0] = new SqlParameter("@countryid", countryid);
                SqlParam[1] = new SqlParameter("@status", countrystatus);
                SqlParam[2] = new SqlParameter("@countryname", countryname);
                SqlParam[3] = new SqlParameter("@Out_Error", SqlDbType.NVarChar, 200);
                SqlParam[3].Direction = ParameterDirection.Output;
                int r = DataAccess.Instance.DBInsertCommand("prcInsUpdCountry", SqlParam);
                error = Convert.ToString(SqlParam[3].Value);

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        /*Add #CC01*/
        public DataTable SelectRegionList()
        {
            SqlParameter[] objSqlParam = new SqlParameter[2];
            objSqlParam[0] = new SqlParameter("@regionid", regionid);
            objSqlParam[1] = new SqlParameter("@regionname", regionname);
            d1 = DataAccess.Instance.GetTableFromDatabase("prcRegionMaster_SelectList", CommandType.StoredProcedure, objSqlParam);
            return d1;
        }
       /*End*/

        /*Add #CC01*/
        public DataTable SelectStateList()
        {
            SqlParameter[] objSqlParam = new SqlParameter[2];
            objSqlParam[0] = new SqlParameter("@stateid", stateid);
            objSqlParam[1] = new SqlParameter("@statename", statename);
            d1 = DataAccess.Instance.GetTableFromDatabase("prcGetSchemeStateDetails", CommandType.StoredProcedure, objSqlParam);
            return d1;
        }
        /*End*/
        /*Add #CC01*/
        public DataTable SelectCityList()
        {
            SqlParameter[] objSqlParam = new SqlParameter[2];
            objSqlParam[0] = new SqlParameter("@cityid", stateid);
            objSqlParam[1] = new SqlParameter("@cityname", statename);
            d1 = DataAccess.Instance.GetTableFromDatabase("prcGetSchemeCityDetails", CommandType.StoredProcedure, objSqlParam);
            return d1;
        }
        /*End*/

        /*Add #CC01*/
        public DataSet SelectStateByRegionId()
        {
            DataSet ds = new DataSet();
            SqlParameter[] objSqlParam = new SqlParameter[3];
            objSqlParam[0] = new SqlParameter("@stateid", stateid);
            objSqlParam[1] = new SqlParameter("@statename", statename);
            objSqlParam[2] = new SqlParameter("@regionid", stateregionid);
            ds = DataAccess.Instance.GetDataSetFromDatabase("prcGetStateLocationDetails", CommandType.StoredProcedure, objSqlParam);

            return ds;
        }
        /*End*/
        /*#CC04 Added*/
        public DataTable SelectList()
        {
            DataTable dtResult = new DataTable();
            SqlParameter[] objSqlParam = new SqlParameter[3];
            objSqlParam[0] = new SqlParameter("@Out_Error", SqlDbType.VarChar, 500);
            objSqlParam[0].Direction = ParameterDirection.Output;
            objSqlParam[1] = new SqlParameter("@countryID", CountryID);
            objSqlParam[2] = new SqlParameter("@active", Active);
            DataSet dsResult = DataAccess.Instance.GetDataSetFromDatabase("prcCountryMaster_SelectList", CommandType.StoredProcedure, objSqlParam);
         
            if (dsResult != null && dsResult.Tables.Count > 0)
                dtResult = dsResult.Tables[0];
            return dtResult;
            
        }
        public static DataTable GetEnumbyTableName(string Filename, string TableName)
        {
            DataTable dt = new DataTable();
            using (DataSet ds = new DataSet())
            {
                string filename = HttpContext.Current.Server.MapPath("~/Assets/XML/" + Filename + ".xml");
                ds.ReadXml(filename);
                dt = ds.Tables[TableName];
                if (dt == null || dt.Rows.Count == 0)
                    return null;
            }
            try
            {
                dt = dt.Select("Active=1").CopyToDataTable();
                return dt;
            }
            catch (Exception)
            {
                return null;
            }
        }
        /*#CC04 End*/
        /*#CC05 Added Started*/
        public DataTable SelectRegionInfo()
        {
            try
            {

                SqlParam = new SqlParameter[1];
                SqlParam[0] = new SqlParameter("@countryid", countryid);
                d1 = DataAccess.Instance.GetTableFromDatabase("prcGetRegionName", CommandType.StoredProcedure, SqlParam);
                return d1;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataTable SelectZoneInfo()
        {
            try
            {

                SqlParam = new SqlParameter[1];
                SqlParam[0] = new SqlParameter("@countryid", countryid);
                d1 = DataAccess.Instance.GetTableFromDatabase("prcGetZoneName", CommandType.StoredProcedure, SqlParam);
                return d1;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        /*#CC05 Added End*/
        #endregion



        #region excel sheetdata
        public string UploadSchemaXml
        {
            get;
            set;
        }

        public int TableID
        {
            get;
            set;
        }

        public string ErrorXmlDetail
        {
            get;
            set;
        }


        public void InsertUploadSchema()
        {
            try
            {
                SqlParam = new SqlParameter[4];
                SqlParam[0] = new SqlParameter("@UploadSchemaXML", SqlDbType.Xml);
                SqlParam[0].Value = new System.Data.SqlTypes.SqlXml(new XmlTextReader(UploadSchemaXml, XmlNodeType.Document, null));
                SqlParam[0].Direction = ParameterDirection.InputOutput;
                SqlParam[1] = new SqlParameter("@ErrorMessage", SqlDbType.VarChar, 200);
                SqlParam[1].Direction = ParameterDirection.Output;
                SqlParam[3] = new SqlParameter("@ErrorXML", SqlDbType.Xml, 2);
                SqlParam[3].Direction = ParameterDirection.Output;
                SqlParam[2] = new SqlParameter("@tableno", TableID);
                DataAccess.Instance.DBInsertCommand("prcInsertMasters", SqlParam);
                if (SqlParam[3].Value.ToString() != "")
                {
                    ErrorXmlDetail = (SqlParam[3].Value).ToString();
                }
                else
                {
                    ErrorXmlDetail = null;
                }
                if (SqlParam[1].Value != DBNull.Value && SqlParam[1].Value.ToString() != "")
                {
                    error = (SqlParam[1].Value).ToString();
                }


            }
            catch (Exception ex)
            {

                throw ex;
            }
        }






        #endregion



        #region State


        int stateid; string statename; string statecode; string statepriceeffdate; int statestatus; int statepricelistid;

        int statepreviouspricelistid; int stateselectionmode; int statecountryid;


        public int StateId
        {
            get { return stateid; }
            set { stateid = value; }
        }

        public string StateName
        {
            get { return statename; }
            set { statename = value; }
        }

        public string StateCode
        {
            get { return statecode; }
            set { statecode = value; }
        }
        public int StateStatus
        {
            get { return statestatus; }
            set { statestatus = value; }

        }

        public string StatePriceEffDate
        {
            get { return statepriceeffdate; }
            set { statepriceeffdate = value; }
        }

        public int StatePriceListId
        {
            get { return statepricelistid; }
            set { statepricelistid = value; }

        }
        public int StatePreviousPriceListId
        {
            get { return statepreviouspricelistid; }
            set { statepreviouspricelistid = value; }

        }
        public int StateSelectionMode
        {
            get { return stateselectionmode; }
            set { stateselectionmode = value; }
        }

        public int StateCountryid
        {
            get { return statecountryid; }
            set { statecountryid = value; }
        }




        public DataTable SelectStateInfo()
        {
            try
            {
                SqlParam = new SqlParameter[8];
                SqlParam[0] = new SqlParameter("@stateid", stateid);
                SqlParam[1] = new SqlParameter("@statename", statename);
                SqlParam[2] = new SqlParameter("@statecode", statecode);
                SqlParam[3] = new SqlParameter("@pricelstid", statepricelistid);
                SqlParam[4] = new SqlParameter("@selectionmode", stateselectionmode);
                SqlParam[5] = new SqlParameter("@countryid", statecountryid);
                SqlParam[6] = new SqlParameter("@SalesChannelID", SalesChannelID);
                SqlParam[7] = new SqlParameter("@CompanyId", CompanyId);/*#CC06 Added*/
                d1 = DataAccess.Instance.GetTableFromDatabase("prcGetStateDetails", CommandType.StoredProcedure, SqlParam);


                return d1;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        public DataTable SelectAllStateInfo()
        {
            try
            {
                stateid = 0;
                statename = "";
                statecode = "";
                statepricelistid = 0;
                stateselectionmode = 1;
                SqlParam = new SqlParameter[6];
                SqlParam[0] = new SqlParameter("@stateid", stateid);
                SqlParam[1] = new SqlParameter("@statename", statename);
                SqlParam[2] = new SqlParameter("@statecode", statecode);
                SqlParam[3] = new SqlParameter("@pricelstid", statepricelistid);
                SqlParam[4] = new SqlParameter("@selectionmode", stateselectionmode);
                SqlParam[5] = new SqlParameter("@countryid", statecountryid);
                d1 = DataAccess.Instance.GetTableFromDatabase("prcGetStateDetails", CommandType.StoredProcedure, SqlParam);

                return d1;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }




        public void InsertStateInfo()
        {
            try
            {

                string outex = "";
                stateid = 0;

                SqlParam = new SqlParameter[9];
                SqlParam[0] = new SqlParameter("@stateid", stateid);
                SqlParam[1] = new SqlParameter("@status", statestatus);
                SqlParam[2] = new SqlParameter("@statename", statename);
                SqlParam[3] = new SqlParameter("@statecode", statecode);
                SqlParam[4] = new SqlParameter("@pricelstid", statepricelistid);
                SqlParam[5] = new SqlParameter("@previouspricelistid", statepreviouspricelistid);
                SqlParam[6] = new SqlParameter("@priceeffdt", statepriceeffdate);
                SqlParam[7] = new SqlParameter("@countryid", statecountryid);
                SqlParam[8] = new SqlParameter("@Out_Error", SqlDbType.NVarChar, 200);
                SqlParam[8].Direction = ParameterDirection.Output;
                int r = DataAccess.Instance.DBInsertCommand("prcInsUpdState", SqlParam);
                error = Convert.ToString(SqlParam[8].Value);

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public void UpdateStateInfo()
        {
            try
            {

                string outex = "";


                SqlParam = new SqlParameter[9];
                SqlParam[0] = new SqlParameter("@stateid", stateid);
                SqlParam[1] = new SqlParameter("@status", statestatus);
                SqlParam[2] = new SqlParameter("@statename", statename);
                SqlParam[3] = new SqlParameter("@statecode", statecode);
                SqlParam[4] = new SqlParameter("@pricelstid", statepricelistid);
                SqlParam[5] = new SqlParameter("@previouspricelistid", statepreviouspricelistid);
                SqlParam[6] = new SqlParameter("@priceeffdt", statepriceeffdate);
                SqlParam[7] = new SqlParameter("@countryid", statecountryid);
                SqlParam[8] = new SqlParameter("@Out_Error", SqlDbType.NVarChar, 200);
                SqlParam[8].Direction = ParameterDirection.Output;
                int r = DataAccess.Instance.DBInsertCommand("prcInsUpdState", SqlParam);
                error = Convert.ToString(SqlParam[8].Value);
                //if (error != null)
                //{
                //    throw new Exception(error);
                //}

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }




        #endregion
        #region NewStateMaster
        public Int32 InsertStatePriceLists()
        {
            try
            {
                SqlParam = new SqlParameter[7];
                SqlParam[0] = new SqlParameter("@StateID", stateid);
                SqlParam[1] = new SqlParameter("@PricelstID", statepricelistid);
                SqlParam[2] = new SqlParameter("@PricelstDate", statepriceeffdate);
                SqlParam[3] = new SqlParameter("@Out_Error", SqlDbType.NVarChar, 200);
                SqlParam[3].Direction = ParameterDirection.Output;
                SqlParam[4] = new SqlParameter("@Out_Param", SqlDbType.TinyInt, 2);
                SqlParam[4].Direction = ParameterDirection.Output;
                SqlParam[5] = new SqlParameter("@Purpose", Purpose);
                SqlParam[6] = new SqlParameter("@PriceListChangeLogID", UniqueID);
                int r = DataAccess.Instance.DBInsertCommand("prcInsUpdStatePriceList", SqlParam);
                error = Convert.ToString(SqlParam[3].Value);
                IntResultCount = Convert.ToInt32(SqlParam[4].Value);
                return IntResultCount;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void InsertStateInfoVer2()
        {
            try
            {

                string outex = "";
                stateid = 0;

                SqlParam = new SqlParameter[10];
                SqlParam[0] = new SqlParameter("@stateid", stateid);
                SqlParam[1] = new SqlParameter("@status", statestatus);
                SqlParam[2] = new SqlParameter("@statename", statename);
                SqlParam[3] = new SqlParameter("@statecode", statecode);
                SqlParam[4] = new SqlParameter("@pricelstid", statepricelistid);
                SqlParam[5] = new SqlParameter("@previouspricelistid", statepreviouspricelistid);
                SqlParam[6] = new SqlParameter("@priceeffdt", statepriceeffdate);
                SqlParam[7] = new SqlParameter("@countryid", statecountryid);
                SqlParam[8] = new SqlParameter("@Out_Error", SqlDbType.NVarChar, 200);
                SqlParam[8].Direction = ParameterDirection.Output;
                SqlParam[9] = new SqlParameter("@RegionId", RegionId);/*#CC05 Added*/
                int r = DataAccess.Instance.DBInsertCommand("prcInsUpdStateVer2", SqlParam);
                error = Convert.ToString(SqlParam[8].Value);

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void UpdateStateInfoVer2()
        {
            try
            {

                string outex = "";


                SqlParam = new SqlParameter[10];
                SqlParam[0] = new SqlParameter("@stateid", stateid);
                SqlParam[1] = new SqlParameter("@status", statestatus);
                SqlParam[2] = new SqlParameter("@statename", statename);
                SqlParam[3] = new SqlParameter("@statecode", statecode);
                SqlParam[4] = new SqlParameter("@pricelstid", statepricelistid);
                SqlParam[5] = new SqlParameter("@previouspricelistid", statepreviouspricelistid);
                SqlParam[6] = new SqlParameter("@priceeffdt", statepriceeffdate);
                SqlParam[7] = new SqlParameter("@countryid", statecountryid);
                SqlParam[8] = new SqlParameter("@Out_Error", SqlDbType.NVarChar, 200);
                SqlParam[8].Direction = ParameterDirection.Output;
                SqlParam[9] = new SqlParameter("@RegionId", RegionId);
                int r = DataAccess.Instance.DBInsertCommand("prcInsUpdStateVer2", SqlParam);
                error = Convert.ToString(SqlParam[8].Value);
                //if (error != null)
                //{
                //    throw new Exception(error);
                //}

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataTable SelectStateInfoVer2()
        {
            try
            {
                SqlParam = new SqlParameter[7];
                SqlParam[0] = new SqlParameter("@stateid", stateid);
                SqlParam[1] = new SqlParameter("@statename", statename);
                SqlParam[2] = new SqlParameter("@statecode", statecode);
                SqlParam[3] = new SqlParameter("@pricelstid", statepricelistid);
                SqlParam[4] = new SqlParameter("@selectionmode", stateselectionmode);
                SqlParam[5] = new SqlParameter("@countryid", statecountryid);
                SqlParam[6] = new SqlParameter("@UniquePriceListId", UniqueID);
                d1 = DataAccess.Instance.GetTableFromDatabase("prcGetStateDetailsVer2", CommandType.StoredProcedure, SqlParam);


                return d1;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public Int32 DeleteStatePriceListInfo()
        {
            try
            {
                SqlParam = new SqlParameter[5];
                SqlParam[0] = new SqlParameter("@Condition", Condition);
                SqlParam[1] = new SqlParameter("@UniqueID", UniqueID);
                SqlParam[2] = new SqlParameter("@Out_Param", SqlDbType.Int);
                SqlParam[2].Direction = ParameterDirection.Output;
                SqlParam[3] = new SqlParameter("@Out_Error", SqlDbType.NVarChar, 500);
                SqlParam[3].Direction = ParameterDirection.Output;
                SqlParam[4] = new SqlParameter("@StateID", StateId);
                int r = DataAccess.Instance.DBInsertCommand("prcDeleteStatePriceListInfo", SqlParam);
                error = Convert.ToString(SqlParam[3].Value);
                return Convert.ToInt32(SqlParam[2].Value);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        //public Int32 SelectStatePriceListInfo()
        //{
        //    try
        //    {
        //        SqlParam = new SqlParameter[9];
        //        SqlParam[0] = new SqlParameter("@stateid", stateid);
        //        SqlParam[2] = new SqlParameter("@Condition", Condition);
        //        SqlParam[3] = new SqlParameter("@pricelstid", statepricelistid);
        //        SqlParam[6] = new SqlParameter("@UniqueID", UniqueID);
        //        int r = DataAccess.Instance.DBInsertCommand("prcSelectStatePriceListInfo", SqlParam);
        //        error = Convert.ToString(SqlParam[8].Value);
        //        return Convert.ToInt32(SqlParam[5].Value);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

        #endregion

        # region  District


        int districtid; string districtname; string districtcode;
        int districtstateid; int districtstatus; int districtselectionmode; int districtountryid;


        public int DistrictId
        {
            get { return districtid; }
            set { districtid = value; }
        }

        public string DistrictName
        {
            get { return districtname; }
            set { districtname = value; }
        }

        public string DistrictCode
        {
            get { return districtcode; }
            set { districtcode = value; }
        }
        public int DistrictStatus
        {
            get { return districtstatus; }
            set { districtstatus = value; }

        }

        public int DistrictStateId
        {
            get { return districtstateid; }
            set { districtstateid = value; }
        }


        public int DistrictCountryId
        {
            get { return districtountryid; }
            set { districtountryid = value; }
        }

        public int DistrictSelectionMode
        {
            get { return districtselectionmode; }
            set { districtselectionmode = value; }
        }


        public DataTable SelectAllDistrictInfo()
        {
            try
            {
                districtid = 0;
                districtname = "";
                districtstateid = 0;
                districtselectionmode = 1;
                SqlParam = new SqlParameter[6];
                SqlParam[0] = new SqlParameter("@districtid", districtid);
                SqlParam[1] = new SqlParameter("@districtname", districtname);
                SqlParam[2] = new SqlParameter("@districtstateid", districtstateid);
                SqlParam[3] = new SqlParameter("@districtcountryid", districtountryid);
                SqlParam[4] = new SqlParameter("@selectionmode", districtselectionmode);
                SqlParam[5] = new SqlParameter("@districtcode", districtcode);


                d1 = DataAccess.Instance.GetTableFromDatabase("prcGetDistrictDetails", CommandType.StoredProcedure, SqlParam);

                return d1;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        public DataTable SelectDistrictInfo()
        {
            try
            {
                SqlParam = new SqlParameter[7];
                SqlParam[0] = new SqlParameter("@districtstateid", districtstateid);
                SqlParam[1] = new SqlParameter("@districtid", districtid);
                SqlParam[2] = new SqlParameter("@districtname", districtname);
                SqlParam[3] = new SqlParameter("@districtcode", districtcode);
                SqlParam[4] = new SqlParameter("@districtcountryid", districtountryid);
                SqlParam[5] = new SqlParameter("@selectionmode", districtselectionmode);
                SqlParam[6] = new SqlParameter("@CompanyId", CompanyId);/*#CC06 Added*/
                d1 = DataAccess.Instance.GetTableFromDatabase("prcGetDistrictDetails", CommandType.StoredProcedure, SqlParam);
                return d1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public void InsertDistrictInfo()
        {
            try
            {
                string outex = "";
                districtid = 0;
                SqlParam = new SqlParameter[6];
                SqlParam[0] = new SqlParameter("@districtstateid", districtstateid);
                SqlParam[1] = new SqlParameter("@status", districtstatus);
                SqlParam[2] = new SqlParameter("@districtname", districtname);
                SqlParam[3] = new SqlParameter("@districtcode", districtcode);
                SqlParam[4] = new SqlParameter("@districtid", districtid);
                //SqlParam[5] = new SqlParameter("@districtcountryid", districtountryid);
                SqlParam[5] = new SqlParameter("@Out_Error", SqlDbType.NVarChar, 200);
                SqlParam[5].Direction = ParameterDirection.Output;
                int r = DataAccess.Instance.DBInsertCommand("prcInsUpdDistrict", SqlParam);
                error = Convert.ToString(SqlParam[5].Value);

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void UpdateDistrictInfo()
        {
            try
            {

                string outex = "";


                SqlParam = new SqlParameter[6];
                SqlParam[0] = new SqlParameter("@districtid", districtid);
                SqlParam[1] = new SqlParameter("@districtstateid", districtstateid);
                SqlParam[2] = new SqlParameter("@status", districtstatus);
                SqlParam[3] = new SqlParameter("@districtname", districtname);
                SqlParam[4] = new SqlParameter("@districtcode", districtcode);
                //SqlParam[5] = new SqlParameter("@districtcountryid", districtountryid);
                SqlParam[5] = new SqlParameter("@Out_Error", SqlDbType.NVarChar, 200);
                SqlParam[5].Direction = ParameterDirection.Output;
                int r = DataAccess.Instance.DBInsertCommand("prcInsUpdDistrict", SqlParam);
                error = Convert.ToString(SqlParam[5].Value);

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }




        #endregion

        #region City



        int cityid; string cityname; string citycode; int citystateid;
        int citydistrictid; int citystatus; int cityselectionmode; int citycountryid;


        public int CityId
        {
            get { return cityid; }
            set { cityid = value; }
        }

        public string CityName
        {
            get { return cityname; }
            set { cityname = value; }
        }

        public string CityCode
        {
            get { return citycode; }
            set { citycode = value; }
        }
        public int CityStatus
        {
            get { return citystatus; }
            set { citystatus = value; }

        }

        public int CityStateId
        {
            get { return citystateid; }
            set { citystateid = value; }
        }


        public int CityCountryId
        {
            get { return citycountryid; }
            set { citycountryid = value; }
        }


        public int CityDistrictId
        {
            get { return citydistrictid; }
            set { citydistrictid = value; }
        }

        public int CitySelectionMode
        {
            get { return cityselectionmode; }
            set { cityselectionmode = value; }
        }
        /*#CC01  START ADDED*/
        public int tehsillselectionmode
        {
            get;
            set;
        }
        public string tehsillcode
        {
            get;
            set;
        }
        public int tehsillcountryid
        {
            get;
            set;
        }
        public string tehsillname
        {
            get;
            set;
        }
        public int tehsillid
        {
            get;
            set;
        }
        public int tehsilldistrictid
        {
            get;
            set;
        }
        /*#CC03 START ADDED */
        public int tehsilCityId
        {
            get;
            set;
        }
        /*#CC03 START END */
        public int tehsillstateid
        {
            get;
            set;
        }
        public int tehsillstatus
        {
            get;
            set;
        }


        public DataTable SelectTahsillInfo()
        {
            try
            {

                SqlParam = new SqlParameter[9];
                SqlParam[0] = new SqlParameter("@TehsillStateId", tehsillstateid);
                SqlParam[1] = new SqlParameter("@TehsillDistrictId", tehsilldistrictid);
                SqlParam[2] = new SqlParameter("@TehsillId", tehsillid);
                SqlParam[3] = new SqlParameter("@TehsillName", tehsillname);
                SqlParam[4] = new SqlParameter("@TehsillCode", tehsillcode);
                SqlParam[5] = new SqlParameter("@selectionmode", tehsillselectionmode);
                SqlParam[6] = new SqlParameter("@countryid", tehsillcountryid);
                SqlParam[7] = new SqlParameter("@cityid", tehsilCityId);
                SqlParam[8] = new SqlParameter("@CompanyId", CompanyId);/*#CC06 Added*/
                d1 = DataAccess.Instance.GetTableFromDatabase("prcGetTahsillDetails", CommandType.StoredProcedure, SqlParam);
                return d1;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public void InsertTehsilInfo()
        {
            try
            {
                SqlParam = new SqlParameter[8];
                SqlParam[0] = new SqlParameter("@tehsilstateid", tehsillstateid);
                SqlParam[1] = new SqlParameter("@status", tehsillstatus);
                SqlParam[2] = new SqlParameter("@tehsilcode", tehsillcode);
                SqlParam[3] = new SqlParameter("@tehsilname", tehsillname);
                SqlParam[4] = new SqlParameter("@tehsilid", tehsillid);
                SqlParam[5] = new SqlParameter("@tehsildistrictid", tehsilldistrictid);
                SqlParam[6] = new SqlParameter("@Out_Error", SqlDbType.NVarChar, 200);
                SqlParam[6].Direction = ParameterDirection.Output;
                SqlParam[7] = new SqlParameter("@tehsilCityid", tehsilCityId);
                int r = DataAccess.Instance.DBInsertCommand("prcInsUpdTehsill", SqlParam);
                error = Convert.ToString(SqlParam[6].Value);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void UpdateTehsilInfo()
        {
            try
            {
                SqlParam = new SqlParameter[8];
                SqlParam[0] = new SqlParameter("@tehsilid", tehsillid);
                SqlParam[1] = new SqlParameter("@status", tehsillstatus);
                SqlParam[2] = new SqlParameter("@tehsilname", tehsillname);
                SqlParam[3] = new SqlParameter("@tehsilcode", tehsillcode);
                SqlParam[4] = new SqlParameter("@tehsilstateid", tehsillstateid);
                SqlParam[5] = new SqlParameter("@tehsildistrictid", tehsilldistrictid);
                SqlParam[6] = new SqlParameter("@Out_Error", SqlDbType.NVarChar, 200);
                SqlParam[6].Direction = ParameterDirection.Output;
                SqlParam[7] = new SqlParameter("@tehsilCityid", tehsilCityId);
                int r = DataAccess.Instance.DBInsertCommand("prcInsUpdTehsill", SqlParam);
                error = Convert.ToString(SqlParam[6].Value);

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataTable SelectCityInfoTehsilWise()
        {
            try
            {

                SqlParam = new SqlParameter[8];
                SqlParam[0] = new SqlParameter("@citystateid", citystateid);
                SqlParam[1] = new SqlParameter("@citydistrictid", citydistrictid);
                SqlParam[2] = new SqlParameter("@cityid", cityid);
                SqlParam[3] = new SqlParameter("@cityname", cityname);
                SqlParam[4] = new SqlParameter("@citycode", citycode);
                SqlParam[5] = new SqlParameter("@selectionmode", cityselectionmode);
                SqlParam[6] = new SqlParameter("@countryid", citycountryid);
                SqlParam[7] = new SqlParameter("@TehsilId", tehsillid);
                d1 = DataAccess.Instance.GetTableFromDatabase("prcGetCityDetails_ForTehsil", CommandType.StoredProcedure, SqlParam);
                return d1;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /*#CC01  START END*/
        public DataTable SelectCityInfo()
        {
            try
            {

                SqlParam = new SqlParameter[8];
                SqlParam[0] = new SqlParameter("@citystateid", citystateid);
                SqlParam[1] = new SqlParameter("@citydistrictid", citydistrictid);
                SqlParam[2] = new SqlParameter("@cityid", cityid);
                SqlParam[3] = new SqlParameter("@cityname", cityname);
                SqlParam[4] = new SqlParameter("@citycode", citycode);
                SqlParam[5] = new SqlParameter("@selectionmode", cityselectionmode);
                SqlParam[6] = new SqlParameter("@countryid", citycountryid);
                SqlParam[7] = new SqlParameter("@CompanyId", CompanyId);/*#CC06 Added*/
                d1 = DataAccess.Instance.GetTableFromDatabase("prcGetCityDetails", CommandType.StoredProcedure, SqlParam);
                return d1;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public DataTable SelectAllCityInfo()
        {
            try
            {
                cityid = 0;
                cityname = "";
                citycode = "";
                citystateid = 0;
                citydistrictid = 0;
                cityselectionmode = 1;
                SqlParam = new SqlParameter[7];
                SqlParam[0] = new SqlParameter("@cityid", cityid);
                SqlParam[1] = new SqlParameter("@citycode", citycode);
                SqlParam[2] = new SqlParameter("@cityname", cityname);
                SqlParam[3] = new SqlParameter("@citystateid", citystateid);
                SqlParam[4] = new SqlParameter("@citydistrictid", citydistrictid);
                SqlParam[5] = new SqlParameter("@selectionmode", cityselectionmode);
                SqlParam[6] = new SqlParameter("@countryid", citycountryid);
                d1 = DataAccess.Instance.GetTableFromDatabase("prcGetCityDetails", CommandType.StoredProcedure, SqlParam);

                return d1;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        public void InsertCityInfo()
        {
            try
            {
                string outex = "";

                int cityid = 0;

                SqlParam = new SqlParameter[8];
                SqlParam[0] = new SqlParameter("@citystateid", citystateid);
                SqlParam[1] = new SqlParameter("@status", citystatus);
                SqlParam[2] = new SqlParameter("@citycode", citycode);
                SqlParam[3] = new SqlParameter("@cityname", cityname);
                SqlParam[4] = new SqlParameter("@cityid", cityid);
                SqlParam[5] = new SqlParameter("@citydistrictid", citydistrictid);
                SqlParam[6] = new SqlParameter("@Out_Error", SqlDbType.NVarChar, 200);
                SqlParam[6].Direction = ParameterDirection.Output;
                int r = DataAccess.Instance.DBInsertCommand("prcInsUpdCity", SqlParam);
                error = Convert.ToString(SqlParam[6].Value);

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void UpdateCityInfo()
        {
            try
            {

                string outex = "";


                SqlParam = new SqlParameter[8];
                SqlParam[0] = new SqlParameter("@cityid", cityid);
                SqlParam[1] = new SqlParameter("@status", citystatus);
                SqlParam[2] = new SqlParameter("@cityname", cityname);
                SqlParam[3] = new SqlParameter("@citycode", citycode);
                SqlParam[4] = new SqlParameter("@citystateid", citystateid);
                SqlParam[5] = new SqlParameter("@citydistrictid", citydistrictid);
                SqlParam[6] = new SqlParameter("@Out_Error", SqlDbType.NVarChar, 200);
                SqlParam[6].Direction = ParameterDirection.Output;
                int r = DataAccess.Instance.DBInsertCommand("prcInsUpdCity", SqlParam);
                error = Convert.ToString(SqlParam[6].Value);

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        #endregion



        #region area

        int areaid; string areaname; string areacode; int areastateid; int areacountryid;
        int areastatus; int areacityid; int areadistrictid; int areaselectionmode;

        public int AreaId
        {
            get { return areaid; }
            set { areaid = value; }
        }

        public string AreaName
        {
            get { return areaname; }
            set { areaname = value; }
        }

        public string AreaCode
        {
            get { return areacode; }
            set { areacode = value; }
        }
        public int AreaStatus
        {
            get { return areastatus; }
            set { areastatus = value; }

        }

        public int AreaStateId
        {
            get { return areastateid; }
            set { areastateid = value; }
        }

        public int AreaCityId
        {
            get { return areacityid; }
            set { areacityid = value; }
        }

        public int AreaDistrictId
        {
            get { return areadistrictid; }
            set { areadistrictid = value; }
        }

        public int AreaSelectionMode
        {
            get { return areaselectionmode; }
            set { areaselectionmode = value; }
        }

        public int AreaCountryId
        {
            get { return areacountryid; }
            set { areacountryid = value; }
        }

        public DataTable SelectAreaInfo()
        {
            try
            {

                SqlParam = new SqlParameter[9];
                SqlParam[0] = new SqlParameter("@areastateid", areastateid);
                SqlParam[1] = new SqlParameter("@areadistrictid", areadistrictid);
                SqlParam[2] = new SqlParameter("@areacityid", areacityid);
                SqlParam[3] = new SqlParameter("@areaname", areaname);
                SqlParam[4] = new SqlParameter("@areacode", areacode);
                SqlParam[5] = new SqlParameter("@areaid", areaid);
                SqlParam[6] = new SqlParameter("@countryid", areacountryid);
                SqlParam[7] = new SqlParameter("@selectionmode", areaselectionmode);
                SqlParam[8] = new SqlParameter("@areatehsilid", tehsillid);
                d1 = DataAccess.Instance.GetTableFromDatabase("prcGetAreaDetails", CommandType.StoredProcedure, SqlParam);
                return d1;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable SelectAllAreaInfo()
        {
            try
            {
                areaid = 0;
                areaname = "";
                areacode = "";
                areastateid = 0;
                areacityid = 0;
                areadistrictid = 0;
                areaselectionmode = 1;
                SqlParam = new SqlParameter[8];
                SqlParam[0] = new SqlParameter("@areacityid", areacityid);
                SqlParam[1] = new SqlParameter("@areacode", areacode);
                SqlParam[2] = new SqlParameter("@areadistrictid", areadistrictid);
                SqlParam[3] = new SqlParameter("@areaname", areaname);
                SqlParam[4] = new SqlParameter("@areastateid", areastateid);
                SqlParam[5] = new SqlParameter("@areaid", areaid);
                SqlParam[6] = new SqlParameter("@countryid", areacountryid);
                SqlParam[7] = new SqlParameter("@selectionmode", areaselectionmode);
                d1 = DataAccess.Instance.GetTableFromDatabase("prcGetAreaDetails", CommandType.StoredProcedure, SqlParam);
                return d1;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void InsertAreaInfo()
        {
            try
            {

                string outex = "";
                int areaid = 0;

                SqlParam = new SqlParameter[8];
                SqlParam[0] = new SqlParameter("@areastateid", areastateid);
                SqlParam[1] = new SqlParameter("@status", areastatus);
                SqlParam[2] = new SqlParameter("@areacode", areacode);
                SqlParam[3] = new SqlParameter("@areaname", areaname);

                SqlParam[4] = new SqlParameter("@areacityid", areacityid);


                SqlParam[5] = new SqlParameter("@areaid", areaid);


                SqlParam[6] = new SqlParameter("@Out_Error", SqlDbType.NVarChar, 200);
                SqlParam[6].Direction = ParameterDirection.Output;
                SqlParam[7] = new SqlParameter("@tehsilid", tehsillid);
                int r = DataAccess.Instance.DBInsertCommand("prcInsUpdArea", SqlParam);
                error = Convert.ToString(SqlParam[6].Value);

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        public void UpdateAreaInfo()
        {
            try
            {

                string outex = "";


                SqlParam = new SqlParameter[8];
                SqlParam[0] = new SqlParameter("@areacityid", areacityid);
                SqlParam[1] = new SqlParameter("@status", areastatus);
                SqlParam[2] = new SqlParameter("@areaname", areaname);
                SqlParam[3] = new SqlParameter("@areacode", areacode);
                SqlParam[4] = new SqlParameter("@areastateid", areastateid);
                SqlParam[5] = new SqlParameter("@areaid", areaid);

                SqlParam[6] = new SqlParameter("@Out_Error", SqlDbType.NVarChar, 200);
                SqlParam[6].Direction = ParameterDirection.Output;
                SqlParam[7] = new SqlParameter("@tehsilid", tehsillid);
                int r = DataAccess.Instance.DBInsertCommand("prcInsUpdArea", SqlParam);
                error = Convert.ToString(SqlParam[6].Value);

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }




        #endregion

        #region Category
        int categoryid; string categoryname; bool status; int categoryselectionmode;

        public int CategoryID
        {
            get { return categoryid; }
            set { categoryid = value; }
        }

        public string CategoryName
        {
            get { return categoryname; }
            set { categoryname = value; }
        }
        public bool Status
        {
            get { return status; }
            set { status = value; }
        }

        public int CategorySelectionMode
        {
            get { return categoryselectionmode; }
            set { categoryselectionmode = value; }

        }

        public DataTable SelectAllLocalityInfo()
        {
            try
            {

                SqlParam = new SqlParameter[6];
                SqlParam[0] = new SqlParameter("@stateid", StateId);
                SqlParam[1] = new SqlParameter("@DistrictId", DistrictId);
                SqlParam[2] = new SqlParameter("@CityId", CityId);
                SqlParam[3] = new SqlParameter("@countryid", CountryId);
                SqlParam[4] = new SqlParameter("@tehsillid", tehsillid);
                SqlParam[5] = new SqlParameter("@CompanyId", CompanyId);
                d1 = DataAccess.Instance.GetTableFromDatabase("prcGetAllLocalityMasterDetails", CommandType.StoredProcedure, SqlParam);
                return d1;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public void InsertUpdateCategoryInfo()
        {
            try
            {
                string outex = "";


                SqlParam = new SqlParameter[6];
                SqlParam[0] = new SqlParameter("@categoryid", categoryid);
                // SqlParam[0].Direction = ParameterDirection.InputOutput;
                SqlParam[1] = new SqlParameter("@categoryname", categoryname);
                SqlParam[2] = new SqlParameter("@status", Status);

                SqlParam[3] = new SqlParameter("@Out_Error", SqlDbType.NVarChar, 200); ;
                SqlParam[3].Direction = ParameterDirection.Output;
                SqlParam[4] = new SqlParameter("@UserID", UserId);
                SqlParam[5] = new SqlParameter("@CompanyId", CompanyId);

                int r = DataAccess.Instance.DBInsertCommand("PrcInsUpdCategoryInfo", SqlParam);
                //IntResultCount = Convert.ToInt32(SqlParam[0].Value);
                error = Convert.ToString(SqlParam[3].Value);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable SelectCategoryInfo()
        {

            try
            {



                SqlParam = new SqlParameter[5];
                SqlParam[0] = new SqlParameter("@categoryid", categoryid);
                SqlParam[1] = new SqlParameter("@categoryname", categoryname);
                SqlParam[2] = new SqlParameter("@selectionmode", categoryselectionmode);
                SqlParam[3] = new SqlParameter("@UserID", UserId);
                SqlParam[4] = new SqlParameter("@CompanyId", CompanyId);


                d1 = DataAccess.Instance.GetTableFromDatabase("prcSelectCategoryDetails", CommandType.StoredProcedure, SqlParam);


                return d1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable SelectAllCategory()
        {
            try
            {

                categoryid = 0;
                categoryname = "";
                categoryselectionmode = 1;



                SqlParam = new SqlParameter[5];
                SqlParam[0] = new SqlParameter("@categoryid", categoryid);
                SqlParam[1] = new SqlParameter("@categoryname", categoryname);
                SqlParam[2] = new SqlParameter("@selectionmode", categoryselectionmode);
                SqlParam[3] = new SqlParameter("@UserID", UserId);
                SqlParam[4] = new SqlParameter("@CompanyId", CompanyId);


                d1 = DataAccess.Instance.GetTableFromDatabase("prcSelectCategoryDetails", CommandType.StoredProcedure, SqlParam);

                return d1;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion


        #region SubCategory
        int subcategoryid; string subcategoryname; int catid; bool substatus; int subcategoryselectionmode;

        public int SubCategoryID
        {
            get { return subcategoryid; }
            set { subcategoryid = value; }
        }

        public string SubCategoryName
        {
            get { return subcategoryname; }
            set { subcategoryname = value; }
        }
        public bool SubStatus
        {
            get { return substatus; }
            set { substatus = value; }
        }

        public int CatID
        {
            get { return catid; }
            set { catid = value; }
        }

        public int SubCategorySelectionMode
        {
            get { return subcategoryselectionmode; }
            set { subcategoryselectionmode = value; }
        }

        public Int32 UserId { get; set; }
        public Int32 CompanyId { get; set; }
        public DataTable SelectAllSubCategoryInfo()
        {
            try
            {

                subcategoryid = 0;
                subcategoryname = "";
                catid = 0;
                subcategoryselectionmode = 1;


                SqlParam = new SqlParameter[6];
                SqlParam[0] = new SqlParameter("@subcategoryid", subcategoryid);

                SqlParam[1] = new SqlParameter("@subcategoryname", subcategoryname);
                SqlParam[2] = new SqlParameter("@catid", catid);
                SqlParam[3] = new SqlParameter("@selectionmode", subcategoryselectionmode);
                SqlParam[4] = new SqlParameter("@UserID", UserId);

                SqlParam[5] = new SqlParameter("@CompanyId", CompanyId);


                d1 = DataAccess.Instance.GetTableFromDatabase("prcSelectSubCategoryDetails", CommandType.StoredProcedure, SqlParam);


                return d1;

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }


        public DataTable SelectSubCategoryInfo()
        {
            try
            {


                SqlParam = new SqlParameter[6];
                SqlParam[0] = new SqlParameter("@subcategoryid", subcategoryid);
                SqlParam[1] = new SqlParameter("@catid", catid);

                SqlParam[2] = new SqlParameter("@subcategoryname", subcategoryname);
                SqlParam[3] = new SqlParameter("@selectionmode", subcategoryselectionmode);
                SqlParam[4] = new SqlParameter("@UserID", UserId);

                SqlParam[5] = new SqlParameter("@CompanyId", CompanyId);

                d1 = DataAccess.Instance.GetTableFromDatabase("prcSelectSubCategoryDetails", CommandType.StoredProcedure, SqlParam);

                return d1;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable GetAllBulletinSubCategory()
        {
            try
            {
                SqlParam = new SqlParameter[4];
                SqlParam[0] = new SqlParameter("@CategoryID", CategoryID);
                SqlParam[1] = new SqlParameter("@UserID", UserId);

                SqlParam[2] = new SqlParameter("@CompanyId", CompanyId);
                d1 = DataAccess.Instance.GetTableFromDatabase("prcGetAllBulletinSubCategory", CommandType.StoredProcedure, SqlParam);
                return d1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataTable GetAllBulletinSubCategorybyCategoryId()
        {
            try
            {
                SqlParam = new SqlParameter[3];
                SqlParam[0] = new SqlParameter("@CategoryID", CategoryID);
                SqlParam[1] = new SqlParameter("@UserID", UserId);

                SqlParam[2] = new SqlParameter("@CompanyId", CompanyId);
                d1 = DataAccess.Instance.GetTableFromDatabase("prcGetAllBulletinSubCategory", CommandType.StoredProcedure, SqlParam);
                return d1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataTable GetAllBulletinCategory()
        {
            try
            {
                SqlParam = new SqlParameter[3];
                
                SqlParam[0] = new SqlParameter("@UserID", UserId);

                SqlParam[1] = new SqlParameter("@CompanyId", CompanyId);
                d1 = DataAccess.Instance.GetTableFromDatabase("prcGetAllBulletinCategory", CommandType.StoredProcedure, SqlParam);
                return d1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void InsertSubCategoryInfo()
        {
            try
            {
                subcategoryid = 0;

                string outex = "";



                SqlParam = new SqlParameter[7];
                SqlParam[0] = new SqlParameter("@catid", catid);
                SqlParam[1] = new SqlParameter("@substatus", substatus);
                SqlParam[2] = new SqlParameter("@subcategoryname", subcategoryname);
                SqlParam[3] = new SqlParameter("@subcategoryid", subcategoryid);

                SqlParam[4] = new SqlParameter("@Out_Error", outex);
                SqlParam[4].Direction = ParameterDirection.Output;
                SqlParam[5] = new SqlParameter("@UserID", UserId);
                SqlParam[6] = new SqlParameter("@CompanyId", CompanyId);

                int r = DataAccess.Instance.DBInsertCommand("prcInsertUpdSubCategory", SqlParam);
                error = Convert.ToString(SqlParam[4].Value);

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void UpdateSubCategoryInfo()
        {
            try
            {

                string outex = "";


                SqlParam = new SqlParameter[7];
                SqlParam[0] = new SqlParameter("@subcategoryid", subcategoryid);
                SqlParam[1] = new SqlParameter("@catid", catid);
                SqlParam[2] = new SqlParameter("@substatus", substatus);
                SqlParam[3] = new SqlParameter("@subcategoryname", subcategoryname);

                SqlParam[4] = new SqlParameter("@Out_Error", outex);
                SqlParam[4].Direction = ParameterDirection.Output;
                SqlParam[5] = new SqlParameter("@UserID", UserId);
                SqlParam[6] = new SqlParameter("@CompanyId", CompanyId);
                int r = DataAccess.Instance.DBInsertCommand("prcInsertUpdSubCategory", SqlParam);
                error = Convert.ToString(SqlParam[4].Value);

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        #endregion

        # region dispose
        //Call Dispose to free resources explicitly
        private bool IsDisposed = false;
        public void Dispose()
        {
            //Pass true in dispose method to clean managed resources too and say GC to skip finalize 
            // in next line.
            Dispose(true);
            //If dispose is called already then say GC to skip finalize on this instance.
            GC.SuppressFinalize(this);
        }

        ~MastersData()
        {
            //Pass false as param because no need to free managed resources when you call finalize it
            //  will be done
            //by GC itself as its work of finalize to manage managed resources.
            Dispose(false);
        }

        //Implement dispose to free resources
        protected virtual void Dispose(bool disposedStatus)
        {
            if (!IsDisposed)
            {
                IsDisposed = true;
                // Released unmanaged Resources
                if (disposedStatus)
                {
                    // Released managed Resources
                }
            }
        }

        #endregion


    }
}
