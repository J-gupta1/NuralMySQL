﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BusinessLogics
{
    public class clsErrorData
    {
        public Int32 id;
        public string Error;
    }
}
